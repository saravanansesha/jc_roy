import React from "react";

import IntlMessages from "util/IntlMessages";

const Positive_Material_Identification = ({match}) => {
  return (
    <div>
      <h2 className="title gx-mb-4"><IntlMessages id="sidebar.samplePage"/></h2>

      <div className="gx-d-flex justify-content-center">
        <h4>Positive_Material_Identification</h4>
      </div>
 
    </div>
  );
};
    
export default Positive_Material_Identification;
