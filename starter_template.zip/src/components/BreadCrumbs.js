import React from "react";

let BreadCrumb = (props) =>{

    return (
        <div className="bread_crumb">
{props.children}
            </div>
        
    )
}

export default BreadCrumb;