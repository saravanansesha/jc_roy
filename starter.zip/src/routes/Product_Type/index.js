import React from "react";

import IntlMessages from "util/IntlMessages";

const Product_Type = () => {
  return (
    <div>
      <h2 className="title gx-mb-4"><IntlMessages id="sidebar.samplePage"/></h2>

      <div className="gx-d-flex justify-content-center">
        <h4>Product_type</h4>
      </div>

    </div>
  );
};
     
export default Product_Type;
